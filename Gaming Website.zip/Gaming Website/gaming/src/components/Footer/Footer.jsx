import React from 'react';
import { Link } from 'react-router-dom';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-logo">
          <img 
            src="https://cdn-icons-png.flaticon.com/512/2972/2972545.png"
            alt="GameZone Logo" 
            className="footer-logo-img"
          />
          <span className="footer-logo-text">GameZone</span>
        </div>

        <div className="footer-nav">
          <div className="footer-nav-column">
            <h3>Games</h3>
            <ul>
              <li><Link to="/games/action">Action Games</Link></li>
              <li><Link to="/games/adventure">Adventure Games</Link></li>
              <li><Link to="/games/rpg">RPG Games</Link></li>
              <li><Link to="/games/strategy">Strategy Games</Link></li>
            </ul>
          </div>

          <div className="footer-nav-column">
            <h3>Community</h3>
            <ul>
              <li><Link to="/forums">Forums</Link></li>
              <li><Link to="/blog">Blog</Link></li>
              <li><Link to="/events">Events</Link></li>
              <li><Link to="/tournaments">Tournaments</Link></li>
            </ul>
          </div>

          <div className="footer-nav-column">
            <h3>Support</h3>
            <ul>
              <li><Link to="/help">Help Center</Link></li>
              <li><Link to="/faq">FAQ</Link></li>
              <li><Link to="/contact">Contact Us</Link></li>
              <li><Link to="/support">Technical Support</Link></li>
            </ul>
          </div>

          <div className="footer-nav-column">
            <h3>Legal</h3>
            <ul>
              <li><Link to="/privacy">Privacy Policy</Link></li>
              <li><Link to="/terms">Terms of Service</Link></li>
              <li><Link to="/cookies">Cookie Policy</Link></li>
              <li><Link to="/licenses">Licenses</Link></li>
            </ul>
          </div>
        </div>

        <div className="footer-newsletter">
          <h3>Stay Updated</h3>
          <p>Subscribe to our newsletter for the latest gaming news and updates</p>
          <form className="newsletter-form">
            <input type="email" placeholder="Enter your email" required />
            <button type="submit">Subscribe</button>
          </form>
        </div>
      </div>

      <div className="footer-copyright">
        <p>&copy; {new Date().getFullYear()} GameZone. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer; 