import React from 'react';
import './LatestNews.css';

const LatestNews = () => {
  const upcomingGames = [
    {
      id: 1,
      title: 'Grand Theft Auto VI',
      releaseDate: '2026',
      publisher: 'Rockstar Games',
      description: 'The highly anticipated next installment in the GTA series, set in the neon-lit streets of Vice City.',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Grand_Theft_Auto_V_logo.png/1200px-Grand_Theft_Auto_V_logo.png',
      platforms: ['PS5', 'Xbox Series X|S', 'PC']
    },
    {
      id: 2,
      title: 'The Elder Scrolls VI',
      releaseDate: '2026',
      publisher: 'Bethesda Game Studios',
      description: 'The next chapter in the legendary Elder Scrolls series.',
      image: 'https://cdn.akamai.steamstatic.com/steam/apps/306130/header.jpg',
      platforms: ['PS5', 'Xbox Series X|S', 'PC']
    },
    {
      id: 3,
      title: 'Starfield',
      releaseDate: '2025',
      publisher: 'Bethesda Game Studios',
      description: 'A next-generation roleplaying game set in space.',
      image: 'https://cdn.akamai.steamstatic.com/steam/apps/1716740/header.jpg',
      platforms: ['PS5', 'Xbox Series X|S', 'PC']
    },
    
  ];

  return (
    <section className="latest-news">
      <div className="latest-news-content">
        <h2>Upcoming Games</h2>
        <div className="upcoming-games-grid">
          {upcomingGames.map(game => (
            <div key={game.id} className="game-card">
              <div className="game-image-container">
                <img 
                  src={game.image} 
                  alt={game.title}
                  className="game-image"
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.src = 'https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80';
                  }}
                />
                <div className="game-overlay">
                  <span className="release-date">Coming {game.releaseDate}</span>
                </div>
              </div>
              <div className="game-info">
                <h3>{game.title}</h3>
                <p className="publisher">{game.publisher}</p>
                <p className="description">{game.description}</p>
                <div className="platforms">
                  {game.platforms.map((platform, index) => (
                    <span key={index} className="platform-tag">{platform}</span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default LatestNews; 