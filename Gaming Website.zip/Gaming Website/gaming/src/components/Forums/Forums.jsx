import React, { useState } from 'react';
import './Forums.css';

const Forums = () => {
  const [activeTab, setActiveTab] = useState('discussions');

  const members = [
    {
      id: 1,
      name: "GamingPro",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=GamingPro",
      level: "Elite",
      posts: 1250,
      joinDate: "2023-01-15"
    },
    {
      id: 2,
      name: "BattleRoyaleKing",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=BattleRoyaleKing",
      level: "Master",
      posts: 890,
      joinDate: "2023-03-20"
    },
    {
      id: 3,
      name: "RPGFanatic",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=RPGFanatic",
      level: "Veteran",
      posts: 750,
      joinDate: "2023-02-10"
    },
    {
      id: 4,
      name: "StrategyMaster",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=StrategyMaster",
      level: "Elite",
      posts: 1100,
      joinDate: "2023-01-05"
    },
    {
      id: 5,
      name: "IndianGamer",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=IndieGamer",
      level: "Master",
      posts: 680,
      joinDate: "2023-04-15"
    }
  ];

  const discussions = [
    {
      id: 1,
      title: "Best Open World Games of 2024",
      author: "GamingPro",
      category: "General Discussion",
      replies: 45,
      views: 1200,
      lastActivity: "2 hours ago"
    },
    {
      id: 2,
      title: "Tips for New PUBG Players",
      author: "BattleRoyaleKing",
      category: "Battle Royale",
      replies: 32,
      views: 890,
      lastActivity: "5 hours ago"
    },
    {
      id: 3,
      title: "Baldur's Gate 3 Build Guide",
      author: "RPGFanatic",
      category: "RPG",
      replies: 28,
      views: 750,
      lastActivity: "1 day ago"
    },
    {
      id: 4,
      title: "Upcoming Game Releases",
      author: "StrategyMaster",
      category: "News",
      replies: 56,
      views: 1500,
      lastActivity: "3 hours ago"
    },
    {
      id: 5,
      title: "Indie Game Recommendations",
      author: "IndieGamer",
      category: "Indie Games",
      replies: 41,
      views: 920,
      lastActivity: "6 hours ago"
    }
  ];

  return (
    <div className="forums-container">
      <div className="forums-header">
        <h1>Gaming Forums</h1>
        <div className="member-count">
          <span>All Members (180)</span>
        </div>
      </div>

      <div className="forums-tabs">
        <button 
          className={`tab-btn ${activeTab === 'discussions' ? 'active' : ''}`}
          onClick={() => setActiveTab('discussions')}
        >
          Discussions
        </button>
        <button 
          className={`tab-btn ${activeTab === 'members' ? 'active' : ''}`}
          onClick={() => setActiveTab('members')}
        >
          Members
        </button>
      </div>

      {activeTab === 'discussions' ? (
        <div className="discussions-section">
          <div className="discussion-filters">
            <select className="category-filter">
              <option value="all">All Categories</option>
              <option value="general">General Discussion</option>
              <option value="battle-royale">Battle Royale</option>
              <option value="rpg">RPG</option>
              <option value="news">News</option>
              <option value="indie">Indie Games</option>
            </select>
            <button className="new-discussion-btn">Start New Discussion</button>
          </div>

          <div className="discussions-list">
            {discussions.map(discussion => (
              <div key={discussion.id} className="discussion-card">
                <div className="discussion-main">
                  <h3>{discussion.title}</h3>
                  <div className="discussion-meta">
                    <span className="category">{discussion.category}</span>
                    <span className="author">Posted by {discussion.author}</span>
                  </div>
                </div>
                <div className="discussion-stats">
                  <span>💬 {discussion.replies} replies</span>
                  <span>👁️ {discussion.views} views</span>
                  <span>⏰ {discussion.lastActivity}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="members-section">
          <div className="members-grid">
            {members.map(member => (
              <div key={member.id} className="member-card">
                <div className="member-avatar">
                  <img src={member.avatar} alt={member.name} />
                </div>
                <div className="member-info">
                  <h3>{member.name}</h3>
                  <span className={`member-level ${member.level.toLowerCase()}`}>
                    {member.level}
                  </span>
                  <div className="member-stats">
                    <span>📝 {member.posts} posts</span>
                    <span>📅 Joined {member.joinDate}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Forums; 