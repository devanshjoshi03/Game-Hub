import React from 'react';
import { useParams } from 'react-router-dom';
import './GameDetails.css';

const GameDetails = () => {
  const { id } = useParams();

  // This would typically fetch game details from an API
  const gameDetails = {
    id: id,
    title: `Game ${id}`,
    description: 'This is a detailed description of the game.',
    releaseDate: '2024-03-20',
    genre: 'Action',
    rating: '4.5/5',
    image: '/placeholder.jpg'
  };

  return (
    <div className="game-details">
      <div className="game-header">
        <img src={gameDetails.image} alt={gameDetails.title} />
        <div className="game-info">
          <h1>{gameDetails.title}</h1>
          <div className="game-meta">
            <span>Release Date: {gameDetails.releaseDate}</span>
            <span>Genre: {gameDetails.genre}</span>
            <span>Rating: {gameDetails.rating}</span>
          </div>
        </div>
      </div>
      <div className="game-description">
        <h2>About the Game</h2>
        <p>{gameDetails.description}</p>
      </div>
    </div>
  );
};

export default GameDetails; 