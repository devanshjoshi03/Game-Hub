import React from 'react';
import './Games.css';

const Games = () => {
  const games = [
    {
      id: 1,
      title: "Grand Theft Auto V",
      description: "Experience the open world of Los Santos in this action-adventure game. Play as three protagonists in a story of crime and redemption.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/271590/header.jpg",
      genre: "Action-Adventure",
      releaseYear: 2013,
      steamUrl: "https://store.steampowered.com/app/271590/Grand_Theft_Auto_V/"
    },
    {
      id: 2,
      title: "Cyberpunk 2077",
      description: "An open-world action-adventure RPG set in Night City, a megalopolis obsessed with power, glamour, and body modification.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/1091500/header.jpg",
      genre: "RPG",
      releaseYear: 2020,
      steamUrl: "https://store.steampowered.com/app/1091500/Cyberpunk_2077/"
    },
    {
      id: 3,
      title: "Red Dead Redemption 2",
      description: "An epic tale of honor and loyalty at the heart of America's heartland. Play as Arthur Morgan in this western action-adventure.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/1174180/header.jpg",
      genre: "Action-Adventure",
      releaseYear: 2019,
      steamUrl: "https://store.steampowered.com/app/1174180/Red_Dead_Redemption_2/"
    },
    {
      id: 4,
      title: "Elden Ring",
      description: "A new fantasy action-RPG from FromSoftware. Rise, Tarnished, and be guided by grace to brandish the power of the Elden Ring.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/1245620/header.jpg",
      genre: "Action RPG",
      releaseYear: 2022,
      steamUrl: "https://store.steampowered.com/app/1245620/ELDEN_RING/"
    },
    {
      id: 5,
      title: "Baldur's Gate 3",
      description: "An epic RPG set in the world of Dungeons & Dragons. Gather your party and return to the Forgotten Realms in a tale of fellowship and betrayal.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/1086940/header.jpg",
      genre: "RPG",
      releaseYear: 2023,
      steamUrl: "https://store.steampowered.com/app/1086940/Baldurs_Gate_3/"
    },
    {
      id: 6,
      title: "God of War Ragnarök",
      description: "Join Kratos and Atreus on a mythic journey for answers before Ragnarök arrives. Together, father and son must put everything on the line.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/1817070/header.jpg",
      genre: "Action-Adventure",
      releaseYear: 2022,
      steamUrl: "https://store.steampowered.com/app/1817070/God_of_War_Ragnark/"
    },
    {
      id: 7,
      title: "Starfield",
      description: "Bethesda Game Studios' first new universe in 25 years. Explore the vast expanse of space in this next-generation role-playing game.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/1716740/header.jpg",
      genre: "RPG",
      releaseYear: 2023,
      steamUrl: "https://store.steampowered.com/app/1716740/Starfield/"
    },
    {
      id: 8,
      title: "Hogwarts Legacy",
      description: "Experience the wizarding world in an open-world action RPG set in the 1800s. Attend Hogwarts, master spells, and uncover ancient secrets.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/990080/header.jpg",
      genre: "Action RPG",
      releaseYear: 2023,
      steamUrl: "https://store.steampowered.com/app/990080/Hogwarts_Legacy/"
    },
    {
      id: 9,
      title: "Resident Evil 4",
      description: "Survival horror returns with a remake of the classic game. Experience the intense action and horror of Resident Evil 4 with modern graphics.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/2050650/header.jpg",
      genre: "Survival Horror",
      releaseYear: 2023,
      steamUrl: "https://store.steampowered.com/app/2050650/Resident_Evil_4/"
    },
    {
      id: 10,
      title: "Street Fighter 6",
      description: "The latest entry in the legendary fighting game series. Choose your fighter, master their moves, and become the world's greatest warrior.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/1364780/header.jpg",
      genre: "Fighting",
      releaseYear: 2023,
      steamUrl: "https://store.steampowered.com/app/1364780/Street_Fighter_6/"
    }
  ];

  return (
    <div className="games-container">
      <h1>Our Game Collection</h1>
      <div className="games-grid">
        {games.map((game) => (
          <div key={game.id} className="game-card">
            <div className="game-image-container">
              <img 
                src={game.image} 
                alt={game.title}
                className="game-image"
                onError={(e) => {
                  e.target.onerror = null;
                  e.target.src = 'https://via.placeholder.com/400x225?text=Game+Image';
                }}
              />
            </div>
            <div className="game-info">
              <h2>{game.title}</h2>
              <p className="game-genre">{game.genre}</p>
              <p className="game-year">Released: {game.releaseYear}</p>
              <p className="game-description" style={{color:"black"}}>{game.description}</p>
              <a 
                href={game.steamUrl} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="play-now-btn"
              >
                Play Now on Steam
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Games; 