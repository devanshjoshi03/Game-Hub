import React from 'react';
import './GameReviews.css';

const GameReviews = () => {
  const gameReviews = [
    {
      id: 1,
      title: 'Grand Theft Auto V',
      rating: 9.5,
      review: 'A masterpiece of open-world gaming that continues to set the standard for the genre.',
      image: 'https://cdn.akamai.steamstatic.com/steam/apps/271590/header.jpg',
      genre: 'Action-Adventure',
      releaseYear: '2013'
    },
    {
      id: 2,
      title: 'Forza Horizon 5',
      rating: 8.7,
      review: "A sun-soaked racing paradise where speed meets freedom, blending brutal horsepower with breathtaking open-world exploration in Mexico's vibrant landscapes.",
      image: 'https://cdn.akamai.steamstatic.com/steam/apps/1551360/header.jpg',
      genre: 'Racing',
      releaseYear: '2021'
    },
    {
      id: 3,
      title: 'Apex Legends',
      rating: 9.3,
      review: 'A high-octane battle royale that redefines teamplay, where elite Legends clash in a fast-paced, ever-evolving arena of skill and strategy.',
      image: 'https://cdn.akamai.steamstatic.com/steam/apps/1172470/header.jpg',
      genre: 'Battle Royale',
      releaseYear: '2019'
    },
    {
      id: 4,
      title: 'Resident Evil 4 Remake',
      rating: 9.2,
      review: 'A masterful reimagining of a classic that sets new standards for remakes.',
      image: 'https://cdn.akamai.steamstatic.com/steam/apps/2050650/header.jpg',
      genre: 'Survival Horror',
      releaseYear: '2023'
    },
    {
      id: 5,
      title: 'Cyberpunk 2077',
      rating: 8.5,
      review: 'A vast, immersive world with compelling characters and stories.',
      image: 'https://cdn.akamai.steamstatic.com/steam/apps/1091500/header.jpg',
      genre: 'RPG',
      releaseYear: '2020'
    },
    {
      id: 6,
      title: 'Watch Dogs: Legion',
      rating: 7.8,
      review: 'An ambitious open-world game with innovative gameplay mechanics.',
      image: 'https://cdn.akamai.steamstatic.com/steam/apps/2239550/header.jpg',
      genre: 'Action-Adventure',
      releaseYear: '2020'
    }
  ];

  return (
    <section className="game-reviews">
      <div className="game-reviews-content">
        <h2>Recent Game Reviews</h2>
        <div className="reviews-grid">
          {gameReviews.map((game) => (
            <div key={game.id} className="review-card">
              <div className="review-image-container">
                <img 
                  src={game.image} 
                  alt={game.title}
                  className="review-image"
                  onError={(e) => {
                    e.target.src = 'https://via.placeholder.com/400x600?text=Game+Image';
                  }}
                />
                <div className="review-overlay">
                  <div className="rating-badge">
                    <span className="rating-number">{game.rating}</span>
                    <span className="rating-max">/10</span>
                  </div>
                </div>
              </div>
              <div className="review-info">
                <h3>{game.title}</h3>
                <div className="review-meta">
                  <span className="genre">{game.genre}</span>
                  <span className="year">{game.releaseYear}</span>
                </div>
                <p className="review-text">{game.review}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default GameReviews; 