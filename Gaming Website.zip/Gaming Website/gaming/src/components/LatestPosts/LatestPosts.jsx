import React from 'react';
import './LatestPosts.css';

const LatestPosts = () => {
  const launchPosts = [
    {
      id: 1,
      title: "GTA 5 Launch",
      date: "17-09-2013",
      author: "Admin",
      content: "Experience the epic launch of GTA 5 with stunning graphics and immersive gameplay. Join millions of players in Los Santos!",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/271590/header.jpg",
      likes: 1250,
      comments: 342
    },
    {
      id: 2,
      title: "PUBG: BATTLEGROUNDS",
      date: "23-03-2917",
      author: "Admin",
      content: "PUBG is now live! Drop into the battlegrounds and fight for survival in this intense battle royale experience.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/578080/header.jpg",
      likes: 980,
      comments: 256
    },
    {
      id: 3,
      title: "Tekken 8",
      date: "26-01-2024",
      author: "Admin",
      content: "The legendary fighting game series returns with Tekken 8. Master new characters and dominate the tournament scene!",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/1778820/header.jpg",
      likes: 1560,
      comments: 423
    }
  ];

  const topComments = [
    {
      id: 1,
      author: "GamingPro",
      content: "The graphics in GTA 5 are absolutely mind-blowing! Can't wait to explore Los Santos.",
      date: "01-02-2025",
      likes: 245
    },
    {
      id: 2,
      author: "BattleRoyaleFan",
      content: "PUBG's new map is incredible. The gameplay mechanics are smoother than ever!",
      date: "09-03-2025",
      likes: 189
    },
    {
      id: 3,
      author: "FightingGameMaster",
      content: "Tekken 8's new characters are amazing. The combat system feels more fluid than ever!",
      date: "03-05-2025",
      likes: 312
    }
  ];

  return (
    <section className="latest-posts">
      <div className="latest-posts-content">
        <h2>Latest Posts</h2>
        
        <div className="posts-section">
          <h3>Game Launches</h3>
          <div className="posts-grid">
            {launchPosts.map(post => (
              <div key={post.id} className="post-card">
                <div className="post-image-container">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="post-image"
                    onError={(e) => {
                      e.target.onerror = null;
                      e.target.src = 'https://via.placeholder.com/400x225?text=Game+Image';
                    }}
                  />
                </div>
                <div className="post-info">
                  <h4>{post.title}</h4>
                  <div className="post-meta">
                    <span>{post.date}</span>
                    <span>By {post.author}</span>
                  </div>
                  <p className="post-content">{post.content}</p>
                  <div className="post-stats">
                    <span>❤️ {post.likes}</span>
                    <span>💬 {post.comments}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="comments-section">
          <h3>Top Comments</h3>
          <div className="comments-list">
            {topComments.map(comment => (
              <div key={comment.id} className="comment-card">
                <div className="comment-header">
                  <span className="comment-author">{comment.author}</span>
                  <span className="comment-date">{comment.date}</span>
                </div>
                <p className="comment-content">{comment.content}</p>
                <div className="comment-footer">
                  <span className="comment-likes">❤️ {comment.likes}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default LatestPosts; 