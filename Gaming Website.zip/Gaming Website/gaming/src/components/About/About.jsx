import React from 'react';
import './About.css';

const About = () => {
  const teamMembers = [
    {
      id: 1,
      name: "Alex Chen",
      role: "Founder & CEO",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
      bio: "Gaming enthusiast with 15+ years of experience in the industry. Founded GameHub to create a better gaming community."
    },
    {
      id: 2,
      name: "Sarah Johnson",
      role: "Creative Director",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
      bio: "Former game designer with a passion for creating immersive gaming experiences. Leads our creative vision."
    },
    {
      id: 3,
      name: "Michael Rodriguez",
      role: "Community Manager",
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
      bio: "Dedicated to building and nurturing our gaming community. Expert in community engagement and event planning."
    }
  ];

  const timelineEvents = [
    {
      year: "2020",
      title: "GameHub Founded",
      description: "Started with a vision to create the ultimate gaming community platform."
    },
    {
      year: "2021",
      title: "Community Launch",
      description: "Launched our community features and hosted our first major gaming tournament."
    },
    {
      year: "2022",
      title: "Global Expansion",
      description: "Expanded our platform to support multiple languages and regions worldwide."
    },
    {
      year: "2023",
      title: "Mobile App Launch",
      description: "Released our mobile app, making GameHub accessible anywhere, anytime."
    }
  ];

  const values = [
    {
      title: "Community First",
      description: "We believe in building strong, supportive gaming communities where everyone feels welcome."
    },
    {
      title: "Innovation",
      description: "Constantly pushing boundaries to create better gaming experiences and features."
    },
    {
      title: "Fair Play",
      description: "Promoting ethical gaming practices and maintaining a fair, competitive environment."
    },
    {
      title: "Inclusivity",
      description: "Creating a space where gamers of all backgrounds can connect and share their passion."
    }
  ];

  return (
    <div className="about-container">
      {/* Hero Section */}
      <section className="hero-section">
        <h1>About GameZone</h1>
        <p className="tagline">Your Ultimate Gaming Community</p>
        <div className="hero-content">
          <p>
            Welcome to GameHub, where gaming enthusiasts unite! We're more than just a platform;
            we're a community of passionate gamers dedicated to creating the best gaming experience
            for everyone. From casual players to competitive gamers, GameHub is your home for all
            things gaming.
          </p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="mission-section">
        <h2>Our Mission</h2>
        <div className="mission-content">
          <p>
            At GameHub, we're on a mission to revolutionize the gaming community experience.
            We believe that gaming is more than just playing – it's about connecting, competing,
            and creating memories together. Our platform brings gamers together, fostering
            friendships and rivalries that last a lifetime.
          </p>
          <div className="mission-stats">
            <div className="stat-card">
              <span className="stat-number">1M+</span>
              <span className="stat-label">Active Users</span>
            </div>
            <div className="stat-card">
              <span className="stat-number">50+</span>
              <span className="stat-label">Game Titles</span>
            </div>
            <div className="stat-card">
              <span className="stat-number">100+</span>
              <span className="stat-label">Daily Tournaments</span>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="team-section">
        <h2>Our Team</h2>
        <div className="team-grid">
          {teamMembers.map(member => (
            <div key={member.id} className="team-card">
              <div className="member-image">
                <img src={member.image} alt={member.name} />
              </div>
              <h3>{member.name}</h3>
              <span className="member-role">{member.role}</span>
              <p className="member-bio">{member.bio}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Timeline Section */}
      <section className="timeline-section">
        <h2>Our Journey</h2>
        <div className="timeline">
          {timelineEvents.map((event, index) => (
            <div key={index} className="timeline-item">
              <span className="timeline-year">{event.year}</span>
              <div className="timeline-content">
                <h3>{event.title}</h3>
                <p>{event.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Values Section */}
      <section className="values-section">
        <h2>Our Values</h2>
        <div className="values-grid">
          {values.map((value, index) => (
            <div key={index} className="value-card">
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default About;