import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';

const Navbar = () => {
  const [isNavOpen, setIsNavOpen] = useState(false);

  const toggleNav = () => {
    setIsNavOpen(!isNavOpen);
  };

  return (
    <nav className="navbar">
      <div className="logo">
        <img 
          src="https://cdn-icons-png.flaticon.com/512/2972/2972545.png"
          alt="Gaming Logo" 
          className="logo-img"
        />
        <span className="logo-text">GameZone</span>
      </div>

      <ul className={`nav-links ${isNavOpen ? 'nav-active' : ''}`}>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/games">Games</Link>
        </li>
        <li>
          <Link to="/blog">Blog</Link>
        </li>
        <li>
          <Link to="/forums">Forums</Link>
        </li>
        <li>
          <Link to="/about">About</Link>
        </li>
        <li>
          <Link to="/contact">Contact</Link>
        </li>
      </ul>

      <div className="auth-buttons">
        {/* <Link to="/login" className="login-btn">Login</Link> */}
        
      </div>

      <div 
        className={`hamburger ${isNavOpen ? 'toggle' : ''}`} 
        onClick={toggleNav}
      >
        <div className="line1"></div>
        <div className="line2"></div>
        <div className="line3"></div>
      </div>
    </nav>
  );
};

export default Navbar;