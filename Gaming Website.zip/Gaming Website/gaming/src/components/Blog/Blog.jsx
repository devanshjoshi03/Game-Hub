import React, { useState } from 'react';
import './Blog.css';

const Blog = () => {
  const [expandedPost, setExpandedPost] = useState(null);

  const blogPosts = [
    {
      id: 1,
      title: "The Evolution of Open World Games",
      author: "John Gaming",
      date: "2024-03-15",
      content: "From the early days of GTA to the vast landscapes of Red Dead Redemption 2, open world games have come a long way. Let's explore how these games have evolved over the years.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/1174180/header.jpg",
      likes: 245,
      comments: [
        { id: 1, author: "GamingPro", text: "Great article! The evolution of graphics has been incredible.", date: "2024-03-15" },
        { id: 2, author: "OpenWorldFan", text: "Don't forget about The Witcher 3's contribution!", date: "2024-03-15" }
      ]
    },
    {
      id: 2,
      title: "RPGs That Changed Gaming Forever",
      author: "Sarah RPG",
      date: "2024-03-14",
      content: "From Final Fantasy to Baldur's Gate 3, RPGs have shaped the gaming landscape. These games have set new standards for storytelling and character development.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/1086940/header.jpg",
      likes: 189,
      comments: [
        { id: 1, author: "RPGFanatic", text: "Baldur's Gate 3 is a masterpiece!", date: "2024-03-14" }
      ]
    },
    {
      id: 3,
      title: "The Rise of Battle Royale Games",
      author: "Mike Battle",
      date: "2024-03-13",
      content: "PUBG and Fortnite revolutionized multiplayer gaming. Let's look at how battle royale games became a global phenomenon.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/578080/header.jpg",
      likes: 312,
      comments: [
        { id: 1, author: "BattleRoyaleKing", text: "PUBG started it all!", date: "2024-03-13" },
        { id: 2, author: "FortniteFan", text: "Fortnite brought in a whole new audience.", date: "2024-03-13" },
        { id: 3, author: "GamingVeteran", text: "The genre has evolved so much.", date: "2024-03-13" }
      ]
    },
    {
      id: 4,
      title: "Indie Games That Made History",
      author: "Lisa Indie",
      date: "2024-03-12",
      content: "Small studios are creating some of the most innovative games. From Minecraft to Stardew Valley, indie games have changed the industry.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/413150/header.jpg",
      likes: 156,
      comments: [
        { id: 1, author: "IndieGamer", text: "Stardew Valley is my favorite!", date: "2024-03-12" }
      ]
    },
    {
      id: 5,
      title: "The Future of VR Gaming",
      author: "Alex VR",
      date: "2024-03-11",
      content: "Virtual Reality is pushing the boundaries of gaming. Let's explore what's next in VR technology and gaming experiences.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/1172470/header.jpg",
      likes: 278,
      comments: [
        { id: 1, author: "VRGaming", text: "Half-Life: Alyx was revolutionary!", date: "2024-03-11" },
        { id: 2, author: "TechEnthusiast", text: "Can't wait for the next generation of VR.", date: "2024-03-11" }
      ]
    },
    {
      id: 6,
      title: "Esports: The New Frontier",
      author: "Tom Esports",
      date: "2024-03-10",
      content: "Competitive gaming has become a global phenomenon. From League of Legends to CS:GO, esports is changing how we view gaming.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/730/header.jpg",
      likes: 198,
      comments: [
        { id: 1, author: "EsportsFan", text: "The prize pools are getting insane!", date: "2024-03-10" }
      ]
    },
    {
      id: 7,
      title: "The Art of Game Design",
      author: "Emma Design",
      date: "2024-03-09",
      content: "What makes a game truly great? Let's dive into the principles of game design and what makes games engaging.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/1245620/header.jpg",
      likes: 167,
      comments: [
        { id: 1, author: "GameDesigner", text: "Level design is crucial!", date: "2024-03-09" },
        { id: 2, author: "CreativeMind", text: "Great insights on game mechanics.", date: "2024-03-09" }
      ]
    },
    {
      id: 8,
      title: "Gaming and Mental Health",
      author: "Dr. Health",
      date: "2024-03-08",
      content: "How gaming affects our mental well-being. The positive and negative impacts of gaming on mental health.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/990080/header.jpg",
      likes: 234,
      comments: [
        { id: 1, author: "MentalHealthPro", text: "Gaming can be therapeutic.", date: "2024-03-08" },
        { id: 2, author: "GamingTherapist", text: "Balance is key.", date: "2024-03-08" }
      ]
    },
    {
      id: 9,
      title: "The Sound of Gaming",
      author: "Sam Audio",
      date: "2024-03-07",
      content: "From 8-bit tunes to orchestral masterpieces. The evolution of game music and sound design.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/1091500/header.jpg",
      likes: 145,
      comments: [
        { id: 1, author: "MusicLover", text: "Cyberpunk's soundtrack is amazing!", date: "2024-03-07" }
      ]
    },
    {
      id: 10,
      title: "Gaming Communities",
      author: "Community Manager",
      date: "2024-03-06",
      content: "How gaming brings people together. The power of gaming communities and their impact on social interaction.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/1817070/header.jpg",
      likes: 189,
      comments: [
        { id: 1, author: "CommunityMember", text: "Gaming friends are the best!", date: "2024-03-06" },
        { id: 2, author: "SocialGamer", text: "Met my best friend through gaming.", date: "2024-03-06" }
      ]
    }
  ];

  const toggleComments = (postId) => {
    setExpandedPost(expandedPost === postId ? null : postId);
  };

  return (
    <div className="blog-container">
      <h1>Gaming Blog</h1>
      
      <div className="blog-grid">
        {blogPosts.map((post) => (
          <article key={post.id} className="blog-post">
            <div className="post-image-container">
              <img 
                src={post.image} 
                alt={post.title}
                className="post-image"
                onError={(e) => {
                  e.target.onerror = null;
                  e.target.src = 'https://via.placeholder.com/400x225?text=Blog+Image';
                }}
              />
            </div>
            
            <div className="post-content">
              <h2>{post.title}</h2>
              <div className="post-meta">
                <span className="post-author">By {post.author}</span>
                <span className="post-date">{post.date}</span>
              </div>
              <p className="post-text">{post.content}</p>
              
              <div className="post-actions">
                <button className="like-btn">❤️ {post.likes}</button>
                <button 
                  className="comments-btn"
                  onClick={() => toggleComments(post.id)}
                >
                  💬 {post.comments.length} Comments
                </button>
              </div>

              {expandedPost === post.id && (
                <div className="comments-section">
                  <h3>Comments</h3>
                  {post.comments.map((comment) => (
                    <div key={comment.id} className="comment">
                      <div className="comment-header">
                        <span className="comment-author">{comment.author}</span>
                        <span className="comment-date">{comment.date}</span>
                      </div>
                      <p className="comment-text">{comment.text}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};

export default Blog; 