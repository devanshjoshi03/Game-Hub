import React from 'react';
import './Tournaments.css';

const Tournaments = () => {
  const upcomingTournaments = [
    {
      id: 1,
      title: 'PUBG Esports World Championship',
      game: 'PUBG: BATTLEGROUNDS',
      startDate: '2024-11-15',
      endDate: '2024-12-15',
      teams: 32,
      prizePool: '$2,000,000',
      image: 'https://cdn.akamai.steamstatic.com/steam/apps/578080/header.jpg'
    },
    {
      id: 2,
      title: 'Tekken World Tour Finals',
      game: 'Tekken 8',
      startDate: '2024-12-01',
      endDate: '2024-12-03',
      teams: 16,
      prizePool: '$100,000',
      image: 'https://cdn.akamai.steamstatic.com/steam/apps/1778820/header.jpg'
    },
    {
      id: 3,
      title: 'FIFA eWorld Cup',
      game: 'EA Sports FC 24',
      startDate: '2024-12-10',
      endDate: '2024-12-12',
      teams: 24,
      prizePool: '$500,000',
      image: 'https://cdn.akamai.steamstatic.com/steam/apps/2195250/header.jpg'
    }
  ];

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <section className="tournaments">
      <div className="tournaments-content">
        <h2>Upcoming Tournaments</h2>
        <div className="tournaments-grid">
          {upcomingTournaments.map((tournament) => (
            <div key={tournament.id} className="tournament-card">
              <div className="tournament-image-container">
                <img 
                  src={tournament.image} 
                  alt={tournament.title}
                  className="tournament-image"
                  onError={(e) => {
                    e.target.src = 'https://via.placeholder.com/400x225?text=Tournament';
                  }}
                />
                <div className="tournament-overlay">
                  <span className="tournament-game">{tournament.game}</span>
                </div>
              </div>
              <div className="tournament-info">
                <h3>{tournament.title}</h3>
                <div className="tournament-dates">
                  <p>Start: {formatDate(tournament.startDate)}</p>
                  <p>End: {formatDate(tournament.endDate)}</p>
                </div>
                <div className="tournament-details">
                  <p className="teams-count">{tournament.teams} Teams</p>
                  <p className="prize-pool">Prize Pool: {tournament.prizePool}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Tournaments; 