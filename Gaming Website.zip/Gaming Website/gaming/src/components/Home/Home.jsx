import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css'; // Make sure to create this CSS file for styling

const Home = () => {
  const featuredGames = [
    {
      id: 1,
      title: "Grand Theft Auto V",
      description: "Experience the open world of Los Santos in this action-adventure game.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/271590/header.jpg",
      link: "/games/1"
    },
    {
      id: 2,
      title: "PUBG: BATTLEGROUNDS",
      description: "Battle royale game where 100 players fight to be the last one standing.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/578080/header.jpg",
      link: "/games/2"
    },
    {
      id: 3,
      title: "Tekken 8",
      description: "The latest installment in the legendary fighting game series.",
      image: "https://cdn.akamai.steamstatic.com/steam/apps/1778820/header.jpg",
      link: "/games/3"
    }
  ];

  return (
    <div className="home">
      <section className="hero">
        <div className="hero-content">
          <h1>Welcome to GameZone</h1>
          <p>Your ultimate destination for gaming news, reviews, and community</p>
          <Link to="/games" className="cta-button">Explore Games</Link>
        </div>
      </section>

      <section className="featured-games">
        <h2>Featured Games</h2>
        <div className="games-grid">
          {featuredGames.map((game) => (
            <div key={game.id} className="game-card">
              <div className="game-image-container">
                <img 
                  src={game.image} 
                  alt={game.title}
                  className="game-image"
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.src = "https://via.placeholder.com/300x200?text=Game+Image";
                  }}
                />
              </div>
              <div className="game-info">
                <h3>{game.title}</h3>
                <p>{game.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;