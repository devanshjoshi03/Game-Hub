import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar/Navbar';
import Home from './components/Home/Home';
import Games from './components/Games/Games';
import Tournaments from './components/Tournaments/Tournaments';
import GameReviews from './components/GameReviews/GameReviews';
import LatestNews from './components/LatestNews/LatestNews';
import LatestPosts from './components/LatestPosts/LatestPosts';
import Blog from './components/Blog/Blog';
import Forums from './components/Forums/Forums';
import About from './components/About/About';
import Contact from './components/Contact/Contact';
import GameDetails from './components/GameDetails/GameDetails';
import Footer from './components/Footer/Footer';
import Login from './components/Login/Login';
import './App.css';

function App() {
  return (
    <Router>
      <div className="app">
        <Navbar />
        <main className="main-content">
          <Routes>
            <Route path="/" element={
              <>
                <Home />
                <LatestNews />
                <Tournaments />
                <GameReviews />
                <LatestPosts />
              </>
            } />
            <Route path="/games" element={
              <>
                <Games />
                <LatestPosts />
              </>
            } />
            <Route path="/tournaments" element={
              <>
                <Tournaments />
                <LatestPosts />
              </>
            } />
            <Route path="/reviews" element={
              <>
                <GameReviews />
                <LatestPosts />
              </>
            } />
            <Route path="/news" element={
              <>
                <LatestNews />
                <LatestPosts />
              </>
            } />
            <Route path="/blog" element={
              <>
                <Blog />
                <LatestPosts />
              </>
            } />
            <Route path="/forums" element={
              <>
                <Forums />
                <LatestPosts />
              </>
            } />
            <Route path="/about" element={
              <>
                <About />
                <LatestPosts />
              </>
            } />
            <Route path="/contact" element={
              <>
                <Contact />
                <LatestPosts />
              </>
            } />
            <Route path="/game/:id" element={
              <>
                <GameDetails />
                <LatestPosts />
              </>
            } />
            <Route path="/login" element={
              <>
                <Login/>
                <LatestPosts />
              </>
            } />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
